# TAO Sample Notebook

## Overview

This repository contains the example TAO Jupyter Notebook that was use to build the sample classification pipeline.  Information on downloading this example notebook and others for TAO can be found at: [Examples Doc](https://docs.nvidia.com/tao/tao-toolkit/text/tao_toolkit_quick_start_guide.html#cv-samples) 

## Reviewing Sample Notebook

I've included a simple Dockerfile that will build a container with Jupyter, the sample notebook, and configuration files for TAO.  It should almost run, but you'll need to set the appropriate directory pointers.  When I get a few moments, I'll clean it up.
