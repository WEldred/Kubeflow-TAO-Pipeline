#!/bin/bash

docker build -t tao-toolkit-tf-kf:3.21.08 -f Dockerfile .
