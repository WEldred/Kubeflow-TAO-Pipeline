#!/bin/bash

docker run -ti -v $HOME:$HOME tao-toolkit-tf-kf:3.21.08
