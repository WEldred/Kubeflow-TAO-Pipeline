# Custom Docker Container for TAO Components of Kubeflow Pipeline

This Dockerfile builds a container that is used as the basis for running TAO components in Kubeflow Pipeline.
